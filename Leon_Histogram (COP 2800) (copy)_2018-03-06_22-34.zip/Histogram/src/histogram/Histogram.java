//package histogram;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Yasmany Leon
 */
public class Histogram {

    int[] a = new int[101];

    public void addValue(int i) {
        if (i > 0 && i <= 10) {
            a[0]++;
        } else if (i >= 11 && i <= 20) {
            a[1]++;
        } else if (i >= 21 && i <= 30) {
            a[2]++;
        } else if (i >= 31 && i <= 40) {
            a[3]++;
        } else if (i >= 41 && i <= 50) {
            a[4]++;
        } else if (i >= 51 && i <= 60) {
            a[5]++;
        } else if (i >= 61 && i <= 70) {
            a[6]++;
        } else if (i >= 71 && i <= 80) {
            a[7]++;
        } else if (i >= 81 && i <= 90) {
            a[8]++;
        } else if (i >= 91 && i <= 100) {
            a[9]++;
        }

    }

    public void viewHistogram() {
        
        System.out.print("1- 10\t |");
        for(int i = 0; i < a[0]; i++){ 
            System.out.print("*");
        }
         System.out.println("");
        System.out.print("11-20\t |");
        for(int i = 0; i < a[1]; i++)
        {
            System.out.print("*");
        }
        System.out.println("");
        System.out.print("21-30\t |");
        for(int i = 0; i < a[2]; i++)
        {
            System.out.print("*");
          
        }
         System.out.println("");
        System.out.print("31-40\t |");
        for(int i = 0; i < a[3]; i++)
        {
            System.out.print("*");
        }
         System.out.println("");
        System.out.print("41-50\t |");
        for(int i = 0; i < a[4]; i++)
        {
            System.out.print("*");
        }
         System.out.println("");
        System.out.print("51-60\t |");
        for(int i = 0; i < a[5]; i++)
        {
            System.out.print("*");
        }
         System.out.println("");
        System.out.print("61-70\t |");
        for(int i = 0; i < a[6]; i++)
        {
            System.out.print("*");
        }
         System.out.println("");
        System.out.print("71-80\t |");
        for(int i = 0; i < a[7]; i++)
        {
            System.out.print("*");
        }
         System.out.println("");
        System.out.print("81-90\t |");
        for(int i = 0; i < a[8]; i++)
        {
            System.out.print("*");
        }
         System.out.println("");
        System.out.print("91-100\t |");
        for(int i = 0; i < a[9]; i++)
        {
            System.out.print("*");
        }
      /*  for (int l = 0; l < myarray.length; l++) {

            for (int t = 0; t < myarray[]; t++) {
                System.out.print("*");
                System.out.println("");
            }
        }*/
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        Histogram h = new Histogram();
        int curNumber = 0;
        while (curNumber >= 0 && curNumber <= 100) {
            while (!scanner.hasNextInt()) {
                scanner.next();
            }
            curNumber = scanner.nextInt();
            h.addValue(curNumber);
        }
        h.viewHistogram();

    }

}
